package com.user.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.user.entity.User;

@Service
public class UserServiceImpl implements UserService {
	//fake user list
	
	List<User> list = List.of(
		new User(3211L,"Gokul","9398429224"),
		new User(3212L,"Preeja","9398429324"),
	    new User(3213L,"Anagha","9398429214")
			
			);
			
	@Override
	public User getUser(Long id) {
		
		return this.list.stream().filter(user->user.getUserId().equals(id)).findAny().orElse(null);
	
	}

}
